---
name: Feature request
about: Submit a feature request
---

**Warning!**
It is highly recommended to discuss feature requests in [the mailing lists](https://logging.apache.org/log4j/2.x/support.html) first.

[A clear and concise description of the feature requested.]
